
# 🎧 AI Media Scheduler

This is a smart media scheduler powered by AI and data science. It rotates through your selected audio, video, and PDF files, plays one each day, and provides AI-powered PDF summaries. It also tracks your usage, visualizes your media habits, and offers recommendations.

## 🚀 Features
- 🎵 Plays one audio/video file daily at scheduled time
- 📄 Summarizes PDFs using AI (T5)
- 🧠 Extracts keywords as tags
- 📈 Usage dashboard with charts
- 🔥 Daily streak tracking
- 🤖 Recommends most-used media type
- 💾 Exports usage logs as CSV

## 📁 How to Use
1. Upload your media files to Google Drive.
2. Update `media_schedule` with your file paths.
3. Run the script in Google Colab.
4. Use commands like `show_log()`, `show_dashboard()`.

## 🧪 Built With
- Python 3
- Google Colab
- Transformers (HuggingFace)
- PyPDF2
- Matplotlib & Seaborn
- Schedule (for timing)

## 📂 Project Files
- `ai_media_scheduler.py` – Full app source code
- `requirements.txt` – All dependencies
- `README.md` – Project overview

## 👤 Author
Chef Boss (Abubakar Saleh) – 3MTT Fellow

## 📣 Hashtags
#3MTTLearningCommunity #My3MTT #AIScheduler #PythonProject
